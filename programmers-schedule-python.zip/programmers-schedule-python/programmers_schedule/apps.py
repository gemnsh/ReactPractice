from django.apps import AppConfig


class ProgrammersScheduleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'programmers_schedule'
